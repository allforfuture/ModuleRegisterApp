﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Net;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            // POSTメソッドで渡すパラメータ
            string param = "";

            // Dictionaryオブジェクト
            var dic = new Dictionary<string, string>();
            dic["serial_cd"] = "GH98467CK0RJDXVAE";

            // POSTメソッドのパラメータ作成
            foreach (string key in dic.Keys)
                param += String.Format("{0}={1}&", key, dic[key]);
                //param += String.Format("{0}&", dic[key]);

            // paramをASCII文字列にエンコードする
            byte[] data = Encoding.ASCII.GetBytes(param);

            ServicePointManager.Expect100Continue = false; // HTTPエラー(417)対応
            // リクエスト作成
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://172.27.32.30/pqm_aoi_api/check_module.php");
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;

            // ポストデータをリクエストに書き込む
            using (Stream reqStream = request.GetRequestStream())
                reqStream.Write(data, 0, data.Length);

            // レスポンスの取得
            WebResponse response = request.GetResponse();

            // 結果の読み込み
            string htmlString = "";
            using (Stream resStream = response.GetResponseStream())
            using (var reader = new StreamReader(resStream, Encoding.GetEncoding("UTF-8")))
                htmlString = reader.ReadToEnd();

            // 結果の出力
            Console.WriteLine(htmlString);

            Console.Write("Press enter to end:");
            Console.ReadLine();
        }
    }
}
